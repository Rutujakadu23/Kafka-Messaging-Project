package com.example.otp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZeptoApplicationTests {

	@Test
	void contextLoads() {
	}

}
