package com.example.otp.model;

public class Checkout {
	
	
	
	
	
	
	

}
