package com.example.otp.util;

import com.example.otp.model.Buyer;
import com.example.otp.model.Order;
import com.example.otp.model.Product;
import com.example.otp.model.Supplier;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.OutputStream;

public class InvoicePdfGenerator {

    public static void generateInvoice(OutputStream outputStream, Order order) throws Exception {
        Document document = new Document();
        PdfWriter.getInstance(document, outputStream);
        document.open();

        // Title
        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 20);
        Paragraph title = new Paragraph("Invoice", titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        document.add(title);
        document.add(new Paragraph(" "));

        // Order Info
        document.add(new Paragraph("Order ID: " + order.getId()));
        document.add(new Paragraph("Order Date: " + order.getOrderDate()));
        document.add(new Paragraph("Total Amount: ₹" + order.getTotalPrice()));
        document.add(new Paragraph(" "));

        // Buyer Info
        Buyer buyer = order.getBuyer();
        document.add(new Paragraph("Buyer: " + buyer.getName()));
        document.add(new Paragraph("Phone: " + buyer.getPhoneNumber()));
        document.add(new Paragraph("Address: " + buyer.getAddress()));
        document.add(new Paragraph(" "));

        // Table Header
        PdfPTable table = new PdfPTable(5);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10f);
        table.setSpacingAfter(10f);
        table.addCell("Product");
        table.addCell("Price");
        table.addCell("Quantity");
        table.addCell("Supplier");
        table.addCell("Supplier Phone");

        // Table Data
        Product product = order.getProduct();
        Supplier supplier = order.getSupplier();

        table.addCell(product.getName());
        table.addCell("₹" + product.getPrice());
        table.addCell(String.valueOf(order.getQuantity()));
        table.addCell(supplier.getSupplierName());
        table.addCell(supplier.getPhone()); // Replace with correct method like getEmail() if needed

        document.add(table);

        document.close();
    }
}
