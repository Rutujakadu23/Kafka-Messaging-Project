package com.example.otp.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.otp.model.Order;
import com.example.otp.service.OrderService;
import com.example.otp.util.InvoicePdfGenerator;

import jakarta.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    // ✅ Create orders from buyer's cart (1 product = 1 order)
    @PostMapping("/{buyerId}/create")
    public ResponseEntity<String> createOrderFromCart(@PathVariable Long buyerId) {
        orderService.createOrderFromCart(buyerId);
        return ResponseEntity.ok("Order(s) placed successfully!");
    }

    // ✅ Get all orders by buyer
    @GetMapping("/buyer/{buyerId}")
    public ResponseEntity<List<Order>> getOrdersByBuyer(@PathVariable Long buyerId) {
        List<Order> orders = orderService.getOrdersByBuyer(buyerId);
        return ResponseEntity.ok(orders);
    }

    // ✅ Get specific order by ID
    @GetMapping("/{orderId}")
    public ResponseEntity<Order> getOrderById(@PathVariable Long orderId) {
        Order order = orderService.getOrderById(orderId);
        return ResponseEntity.ok(order);
    }

    // ✅ Update order status (e.g., pending → shipped)
    @PutMapping("/{orderId}/status")
    public ResponseEntity<String> updateOrderStatus(@PathVariable Long orderId, @RequestParam String status) {
        orderService.updateOrderStatus(orderId, status);
        return ResponseEntity.ok("Order status updated successfully!");
    }

    // ✅ Cancel order (update status to "Canceled")
    @PutMapping("/{orderId}/cancel")
    public ResponseEntity<String> cancelOrder(@PathVariable Long orderId) {
        orderService.cancelOrder(orderId);
        return ResponseEntity.ok("Order canceled successfully!");
    }

    // ✅ Return order (update status to "Returned")
    @PutMapping("/{orderId}/return")
    public ResponseEntity<String> returnOrder(@PathVariable Long orderId) {
        orderService.returnOrder(orderId);
        return ResponseEntity.ok("Order returned successfully!");
    }
    
    
    
    
    
    @GetMapping("/invoice/{orderId}")
    public void generateInvoice(@PathVariable Long orderId, HttpServletResponse response) throws Exception {
        Order order = orderService.getOrderById(orderId); // Make sure this method exists
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=invoice.pdf");
        InvoicePdfGenerator.generateInvoice(response.getOutputStream(), order);
    }
    

    // ✅ Calculate expected delivery date for the order
    @GetMapping("/{orderId}/delivery-date")
    public ResponseEntity<LocalDate> calculateDeliveryDate(@PathVariable Long orderId) {
        LocalDate deliveryDate = orderService.calculateDeliveryDate(orderId);
        return ResponseEntity.ok(deliveryDate);
    }
}
