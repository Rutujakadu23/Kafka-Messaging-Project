package com.example.otp.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.otp.model.Buyer;
import com.example.otp.model.Cart;
import com.example.otp.model.CartItem;
import com.example.otp.model.Order;
import com.example.otp.model.OrderItem;
import com.example.otp.model.Product;
import com.example.otp.model.Supplier;
import com.example.otp.repository.BuyerRepository;
import com.example.otp.repository.CartRepository;
import com.example.otp.repository.OrderRepository;
import com.example.otp.repository.ProductRepository;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private BuyerRepository buyerRepository;

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private ProductRepository productRepository;
    
    // Create order from cart items
    public void createOrderFromCart(Long buyerId) {
        Buyer buyer = buyerRepository.findById(buyerId)
                .orElseThrow(() -> new RuntimeException("Buyer not found"));

        // Fetch the list of carts for the buyer (assuming one cart per buyer)
        List<Cart> carts = cartRepository.findByBuyerId(buyerId);

        // Check if the list is empty, indicating no cart found
        if (carts.isEmpty()) {
            throw new RuntimeException("Cart not found for the buyer");
        }

        // Assuming one cart per buyer, select the first one in the list
        Cart cart = carts.get(0);

        Order order = new Order();
        order.setBuyer(buyer);
        order.setOrderDate(LocalDate.now());
        order.setDeliveryDate(LocalDate.now().plusDays(7)); // 7 days for delivery
        order.setStatus("Processing");

        // Calculate the total price
        double totalPrice = 0;
        List<OrderItem> orderItems = new ArrayList<>();

        for (CartItem item : cart.getCartItems()) {
            Product product = item.getProduct();
            int quantity = item.getQuantity();
            double price = product.getPrice();

            // Calculate total price
            totalPrice += price * quantity;

            // Create and populate OrderItem
            OrderItem orderItem = new OrderItem();
            orderItem.setOrder(order); // set relation
            orderItem.setProduct(product);
            orderItem.setQuantity(quantity);
            orderItem.setPrice(price);

            orderItems.add(orderItem);
        }

        order.setTotalPrice(totalPrice);
        order.setDiscount(0); // Set discount if applicable
        order.setOrderItems(orderItems); // set in order before saving

        // Save the order in the repository
        orderRepository.save(order);
    }

    public void placeOrderByCartId(Long cartId) {
        Cart cart = cartRepository.findById(cartId)
                .orElseThrow(() -> new RuntimeException("Cart not found"));

        Buyer buyer = cart.getBuyer();
        List<CartItem> cartItems = cart.getCartItems();

        if (cartItems == null || cartItems.isEmpty()) {
            throw new RuntimeException("Cart is empty, cannot place order");
        }

        Order order = new Order();
        order.setBuyer(buyer);
        order.setStatus("PLACED");

        double totalPrice = 0.0;

        Long productId = cartItems.get(0).getProduct().getId(); // Get ID of product from cart item

        Product productWithSupplier = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        System.out.println("Fetched Supplier: " + productWithSupplier.getSupplier());

        order.setSupplier(productWithSupplier.getSupplier()); // NOW THIS WON'T BE NULL

        for (CartItem item : cartItems) {
            Product product = item.getProduct();
            int quantity = item.getQuantity();
            double price = product.getPrice();
            totalPrice += quantity * price;
        }

        order.setTotalPrice(totalPrice);
        orderRepository.save(order);

        // Clear cart items
        cartItems.clear();
        cartRepository.save(cart);
    }


    // Method to get orders by buyer
    public List<Order> getOrdersByBuyer(Long buyerId) {
        return orderRepository.findByBuyerId(buyerId);
    }

    // Method to get an order by its ID
    public Order getOrderById(Long orderId) {
        return orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
    }

    // Update the order status
    public void updateOrderStatus(Long orderId, String status) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        order.setStatus(status);
        orderRepository.save(order);
    }

    // Method to cancel an order
    public void cancelOrder(Long orderId) {
        updateOrderStatus(orderId, "Cancelled");
    }

    // Method to return an order
    public void returnOrder(Long orderId) {
        updateOrderStatus(orderId, "Returned");
    }

    // Calculate delivery date
    public LocalDate calculateDeliveryDate(Long orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        return order.getOrderDate().plusDays(7); // Assuming 7 days for delivery
    }
}
